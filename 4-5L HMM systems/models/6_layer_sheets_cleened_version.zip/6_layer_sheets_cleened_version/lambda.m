function lambda = lambda(w)
%waveltngth (nm)
lambda=1240/w;
end

